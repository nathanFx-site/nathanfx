<!DOCTYPE html>
	<html lang="en-US">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Log In &lsaquo; Forex RR &#8212; WordPress</title>
	<meta name='robots' content='noindex, follow' />
<link rel='stylesheet' id='dashicons-css' href='https://forex-rr.com/wp-includes/css/dashicons.min.css?ver=6.8.1' media='all' />
<link rel='stylesheet' id='buttons-css' href='https://forex-rr.com/wp-includes/css/buttons.min.css?ver=6.8.1' media='all' />
<link rel='stylesheet' id='forms-css' href='https://forex-rr.com/wp-admin/css/forms.min.css?ver=6.8.1' media='all' />
<link rel='stylesheet' id='l10n-css' href='https://forex-rr.com/wp-admin/css/l10n.min.css?ver=6.8.1' media='all' />
<link rel='stylesheet' id='login-css' href='https://forex-rr.com/wp-admin/css/login.min.css?ver=6.8.1' media='all' />
<link rel='stylesheet' id='wc-stripe-blocks-checkout-style-css' href='https://forex-rr.com/wp-content/plugins/woocommerce-gateway-stripe/build/upe_blocks.css?ver=01e38ce4a409d9a2ff015f6088fdd03e' media='all' />
	<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link rel="icon" href="https://forex-rr.com/wp-content/uploads/2024/06/cropped-Projekt-bez-nazwy-7-1-32x32.png" sizes="32x32" />
<link rel="icon" href="https://forex-rr.com/wp-content/uploads/2024/06/cropped-Projekt-bez-nazwy-7-1-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://forex-rr.com/wp-content/uploads/2024/06/cropped-Projekt-bez-nazwy-7-1-180x180.png" />
<meta name="msapplication-TileImage" content="https://forex-rr.com/wp-content/uploads/2024/06/cropped-Projekt-bez-nazwy-7-1-270x270.png" />
	</head>
	<body class="login no-js login-action-login wp-core-ui  locale-en-us">
	<script>
document.body.className = document.body.className.replace('no-js','js');
</script>

				<h1 class="screen-reader-text">Log In</h1>
			<div id="login">
		<h1 role="presentation" class="wp-login-logo"><a href="https://wordpress.org/">Powered by WordPress</a></h1>
	
		<form name="loginform" id="loginform" action="https://forex-rr.com/wp-login.php" method="post">
			<p>
				<label for="user_login">Username or Email Address</label>
				<input type="text" name="log" id="user_login" class="input" value="" size="20" autocapitalize="off" autocomplete="username" required="required" />
			</p>

			<div class="user-pass-wrap">
				<label for="user_pass">Password</label>
				<div class="wp-pwd">
					<input type="password" name="pwd" id="user_pass" class="input password-input" value="" size="20" autocomplete="current-password" spellcheck="false" required="required" />
					<button type="button" class="button button-secondary wp-hide-pw hide-if-no-js" data-toggle="0" aria-label="Show password">
						<span class="dashicons dashicons-visibility" aria-hidden="true"></span>
					</button>
				</div>
			</div>
						<p class="forgetmenot"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> <label for="rememberme">Remember Me</label></p>
			<p class="submit">
				<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log In" />
									<input type="hidden" name="redirect_to" value="https://forex-rr.com/wp-admin/" />
									<input type="hidden" name="testcookie" value="1" />
			</p>
		</form>

					<p id="nav">
				<a class="wp-login-lost-password" href="https://forex-rr.com/wp-login.php?action=lostpassword">Lost your password?</a>			</p>
			<script>
function wp_attempt_focus() {setTimeout( function() {try {d = document.getElementById( "user_login" );d.focus(); d.select();} catch( er ) {}}, 200);}
wp_attempt_focus();
if ( typeof wpOnload === 'function' ) { wpOnload() }
</script>
		<p id="backtoblog">
			<a href="https://forex-rr.com/">&larr; Go to Forex RR</a>		</p>
			</div>
				<div class="language-switcher">
				<form id="language-switcher" method="get">

					<label for="language-switcher-locales">
						<span class="dashicons dashicons-translation" aria-hidden="true"></span>
						<span class="screen-reader-text">
							Language						</span>
					</label>

					<select name="wp_lang" id="language-switcher-locales"><option value="en_US" lang="en" data-installed="1">English (United States)</option>
<option value="pl_PL" lang="pl" data-installed="1">Polski</option></select>
					
					
					
						<input type="submit" class="button" value="Change">

					</form>
				</div>
			
	<script src="https://forex-rr.com/wp-includes/js/clipboard.min.js?ver=2.0.11" id="clipboard-js"></script>
<script src="https://forex-rr.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script src="https://forex-rr.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script id="zxcvbn-async-js-extra">
var _zxcvbnSettings = {"src":"https:\/\/forex-rr.com\/wp-includes\/js\/zxcvbn.min.js"};
</script>
<script src="https://forex-rr.com/wp-includes/js/zxcvbn-async.min.js?ver=1.0" id="zxcvbn-async-js"></script>
<script src="https://forex-rr.com/wp-includes/js/dist/hooks.min.js?ver=4d63a3d491d11ffd8ac6" id="wp-hooks-js"></script>
<script src="https://forex-rr.com/wp-includes/js/dist/i18n.min.js?ver=5e580eb46a90c2b997e6" id="wp-i18n-js"></script>
<script id="wp-i18n-js-after">
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
</script>
<script id="password-strength-meter-js-extra">
var pwsL10n = {"unknown":"Password strength unknown","short":"Very weak","bad":"Weak","good":"Medium","strong":"Strong","mismatch":"Mismatch"};
</script>
<script src="https://forex-rr.com/wp-admin/js/password-strength-meter.min.js?ver=6.8.1" id="password-strength-meter-js"></script>
<script src="https://forex-rr.com/wp-includes/js/underscore.min.js?ver=1.13.7" id="underscore-js"></script>
<script id="wp-util-js-extra">
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
</script>
<script src="https://forex-rr.com/wp-includes/js/wp-util.min.js?ver=6.8.1" id="wp-util-js"></script>
<script src="https://forex-rr.com/wp-includes/js/dist/dom-ready.min.js?ver=f77871ff7694fffea381" id="wp-dom-ready-js"></script>
<script src="https://forex-rr.com/wp-includes/js/dist/a11y.min.js?ver=3156534cc54473497e14" id="wp-a11y-js"></script>
<script id="user-profile-js-extra">
var userProfileL10n = {"user_id":"0","nonce":"269980d05d"};
</script>
<script src="https://forex-rr.com/wp-admin/js/user-profile.min.js?ver=6.8.1" id="user-profile-js"></script>
	<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"rayId":"96d70b58fdecd3ac","version":"2025.7.0","r":1,"serverTiming":{"name":{"cfExtPri":true,"cfEdge":true,"cfOrigin":true,"cfL4":true,"cfSpeedBrain":true,"cfCacheStatus":true}},"token":"4ba1e6de49d34e02b7087b8c355ce091","b":1}' crossorigin="anonymous"></script>
</body>
	</html>
	